#include "visitor.hpp"

Visitor::Visitor() 
: mDone {false}
{

}