# How to run this project

## Compiling

type these commands in the directory containing this readme:
```
make clean
make
```

## Generating an AST/Typechecking

```
./nlc <.nl file to check>
```

e.g.:
```
./nlc simple.nl
```