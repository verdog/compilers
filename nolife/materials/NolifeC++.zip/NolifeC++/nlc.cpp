#include <parser/nolife_parser.hpp>

int main()

{
  yyparse();
}
