package astv2;

public abstract class ASTNode {
	public abstract String visit();
}
