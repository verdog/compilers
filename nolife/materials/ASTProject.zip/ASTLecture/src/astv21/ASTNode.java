package astv21;

public abstract class ASTNode {
	public abstract String visit();
}
